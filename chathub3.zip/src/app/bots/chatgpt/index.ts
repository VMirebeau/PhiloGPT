import { AbstractBot, SendMessageParams } from '../abstract-bot'
import { ChatGPTMode, getUserConfig } from '~/services/user-config'
import { ChatGPTApiBot } from '../chatgpt-api'
import { ChatGPTWebBot } from '../chatgpt-webapp'

import { useAtom } from 'jotai'
import { useCallback, useEffect, useMemo } from 'react'
import { chatFamily } from '~app/state'
import { BotId } from '../../bots'

type Param = { botId: BotId; page: string }

export class ChatGPTBot extends AbstractBot {
  #bot: ChatGPTApiBot | ChatGPTWebBot

  constructor() {
    super()
    this.#bot = new ChatGPTWebBot()
    getUserConfig().then(({ chatgptMode, chatgptWebappModelName }) => {
      if (chatgptMode === ChatGPTMode.API) {
        this.#bot = new ChatGPTApiBot()
      } else {
        this.#bot = new ChatGPTWebBot(chatgptWebappModelName === 'default' ? undefined : chatgptWebappModelName)
      }
    })

    /*console.log("on initie le dialogue") 

    const prePrompt: SendMessageParams = {  // on envoie le message, mais ne s'inscrit pas dans la discussion !
      prompt: "Entrez votre message ici",
      onEvent: (event) => console.log(event)
    }
    this.#bot.doSendMessage(prePrompt)

    /*

    const prePrompt: SendMessageParams = {  // on envoie le message, mais ne s'inscrit pas dans la discussion !
      prompt: "Entrez votre message ici",
      onEvent: (event) => console.log(event)
    }
    this.doSendMessage(prePrompt);*/
/*
    let botid: BotId = "chatgpt";
    let page: string = "singleton";
    let param: Param = { botId: botid, page: "singleton"}
    const chatAtom = useMemo(() => chatFamily(param), [botid, page])
    const [chatState, setChatState] = useAtom(chatAtom)
    chatState.bot.sendMessage({
      prompt: "Hello les poulets",
      onEvent: (event) => console.log(event),
    })
    */




  }

  doSendMessage(params: SendMessageParams): Promise<void> {
    return this.#bot.doSendMessage(params)
  }

  resetConversation(): void {
    return this.#bot.resetConversation()
  }
}
